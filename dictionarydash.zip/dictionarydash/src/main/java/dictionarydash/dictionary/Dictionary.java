package dictionarydash.dictionary;

import java.util.List;

public interface Dictionary {
    List<String> words();
}