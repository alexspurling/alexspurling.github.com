package dictionarydash.dictionary;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class ResourceDictionary implements Dictionary {

    private final List<String> words;

    public ResourceDictionary(final String dictionaryResource) {
        words = loadWords(dictionaryResource);
    }

    private List<String> loadWords(final String dictionaryResource) {
        final InputStream dictionaryInputStream = this.getClass().getResourceAsStream(dictionaryResource);
        if (dictionaryInputStream == null) {
            throw new DictionaryNotFoundException(dictionaryResource);
        }
        final InputStreamReader inputStreamReader = new InputStreamReader(dictionaryInputStream, Charset.forName("UTF-8"));
        final BufferedReader buffer = new BufferedReader(inputStreamReader);

        //Might consider using Guava's ImmutableList here instead
        return Collections.unmodifiableList(buffer.lines().collect(Collectors.toList()));
    }

    public List<String> words() {
        return words;
    }
}

class DictionaryNotFoundException extends RuntimeException {
    DictionaryNotFoundException(final String resourcePath) {
        super("Could not find dictionary at resource path " + resourcePath);
    }
}
