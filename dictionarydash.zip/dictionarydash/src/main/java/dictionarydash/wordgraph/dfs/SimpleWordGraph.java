package dictionarydash.wordgraph.dfs;

import dictionarydash.dictionary.Dictionary;
import dictionarydash.wordgraph.WordAdjacency;
import dictionarydash.wordgraph.WordGraph;
import dictionarydash.wordgraph.WordNotFoundException;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Uses breadth first search to find the shortest distance between
 * two words.
 */
public class SimpleWordGraph implements WordGraph {

    private final Map<Integer, List<String>> wordsByLength;

    public SimpleWordGraph(final Dictionary dictionary) {
        wordsByLength = getWordsByLength(dictionary);
    }

    private Map<Integer, List<String>> getWordsByLength(Dictionary dictionary) {
        return dictionary.words().stream().collect(Collectors.groupingBy(String::length));
    }

    @Override
    public List<String> wordsAdjacentTo(final String word) {
        return getWordList(word).stream().filter(dictionaryWord -> WordAdjacency.isAdjacent(dictionaryWord, word)).collect(Collectors.toList());
    }

    @Override
    public int shortestDistance(final String word1, final String word2) {
        if (word1.length() != word2.length()) {
            return -1;
        }
        //Verify that these two words actually exist in our word lists
        getWordList(word1);
        getWordList(word2);

        final Set<String> visitedWords = new HashSet<>();
        final Queue<WordAndDistance> queue = new LinkedList<>();
        queue.add(new WordAndDistance(word1, 0));

        while (!queue.isEmpty()) {
            final WordAndDistance wordAndDistance = queue.remove();
            if (!visitedWords.contains(wordAndDistance.word)) {
                visitedWords.add(wordAndDistance.word);
                if (wordAndDistance.word.equals(word2)) {
                    return wordAndDistance.distance;
                }
                for (String adjacentWord : wordsAdjacentTo(wordAndDistance.word)) {
                    queue.add(new WordAndDistance(adjacentWord, wordAndDistance.distance + 1));
                }
            }
        }
        return -1;
    }

    @Override
    public Map<String, Integer> getWordDistances(final String word) {
        final Map<String, Integer> distances = new HashMap<>();
        final Queue<String> queue = new LinkedList<>();

        distances.put(word, 0);
        queue.add(word);

        while (!queue.isEmpty()) {
            final String curWord = queue.remove();
            final int distanceToCurWord = distances.get(curWord);
            final Set<String> unvisitedWords = wordsAdjacentTo(curWord).stream().filter(adj -> !distances.containsKey(adj)).collect(Collectors.toSet());

            queue.addAll(unvisitedWords);
            for (String adjacentWord : unvisitedWords) {
                distances.put(adjacentWord, distanceToCurWord + 1);
            }
        }
        return distances;
    }

    private static class WordAndDistance {
        final String word;
        final int distance;

        private WordAndDistance(String word, int distance) {
            this.word = word;
            this.distance = distance;
        }

        @Override
        public String toString() {
            return word + ", " + distance;
        }
    }

    private List<String> getWordList(String word) {
        List<String> wordsOfLength = wordsByLength.get(word.length());
        if (wordsOfLength == null || wordsOfLength.indexOf(word) == -1) {
            throw new WordNotFoundException(word);
        }
        return wordsOfLength;
    }

}
