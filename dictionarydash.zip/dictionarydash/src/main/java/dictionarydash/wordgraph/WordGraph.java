package dictionarydash.wordgraph;

import java.util.List;
import java.util.Map;

public interface WordGraph {

    /**
     * Returns the list of words adjacent to the given word
     * @param word word to get words adjacent to
     * @throws WordNotFoundException if the word was not found in the word graph
     * @return a list of words adjacent to the given word
     */
    List<String> wordsAdjacentTo(String word) throws WordNotFoundException;

    /**
     * Returns the shortest distance between two words. Distance between two words
     * is the number of letter replacements needed to transform one word to another.
     * Only words of the same length can be transformed from one to the other.
     * Returns -1 for any pair of words for which there is no sequence of transformations.
     * @param word1 first word
     * @param word2 second word
     * @throws WordNotFoundException if either word was not found in the word graph
     * @return the shortest distance between two words
     */
    int shortestDistance(final String word1, final String word2) throws WordNotFoundException;

    /**
     * Returns a map of words to distances from the given word.
     * @param word the word
     * @throws WordNotFoundException if the word was not found in the word graph
     * @return a map of shortest distances from the given word to all other connected words
     */
    Map<String, Integer> getWordDistances(String word);
}
