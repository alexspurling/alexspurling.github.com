package dictionarydash.wordgraph;

public class WordAdjacency {

    /**
     * Returns true if the words given have only a single letter
     * difference. I.e. they are equal lengths and one word can
     * created from the other by replacing a single letter
     * @param word1 first word
     * @param word2 second word
     * @return true if it is possible transform word1 to word2
     */
    public static boolean isAdjacent(final String word1, final String word2) {
        if (word1.length() != word2.length()) {
            return false;
        }
        int lettersDifferent = 0;
        for (int i = 0; i < word2.length(); i++)  {
            if (word1.charAt(i) != word2.charAt(i)) {
                lettersDifferent++;
            }
            if (lettersDifferent > 1) {
                return false;
            }
        }
        return lettersDifferent == 1;
    }
}
