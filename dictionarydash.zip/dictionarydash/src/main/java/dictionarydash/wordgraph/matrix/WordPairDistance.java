package dictionarydash.wordgraph.matrix;

import java.util.Objects;

public class WordPairDistance {
    private final String word1;
    private final String word2;
    private final int distance;

    WordPairDistance(String word1, String word2, int distance) {
        this.word1 = word1;
        this.word2 = word2;
        this.distance = distance;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        WordPairDistance that = (WordPairDistance) o;
        return distance == that.distance &&
                Objects.equals(word1, that.word1) &&
                Objects.equals(word2, that.word2);
    }

    @Override
    public int hashCode() {
        return Objects.hash(word1, word2, distance);
    }

    @Override
    public String toString() {
        return "Distance from " + word1 + " to " + word2 + " is " + distance;
    }
}