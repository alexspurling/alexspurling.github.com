package dictionarydash.wordgraph.matrix;

import dictionarydash.dictionary.Dictionary;
import dictionarydash.wordgraph.WordGraph;
import dictionarydash.wordgraph.WordNotFoundException;

import java.util.List;
import java.util.Map;

/**
 * Takes a Dictionary and calculates the distance between each word
 * and every other word of the same length. Distances are stored in a
 * matrix
 */
public class MatrixWordGraph implements WordGraph {

    private final DistanceMatrices matrices;

    public MatrixWordGraph(final Dictionary dictionary) {
        this.matrices = new DistanceMatrices(dictionary);
    }

    @Override
    public List<String> wordsAdjacentTo(String word) {
        return getDistanceMatrix(word).wordsAdjacentTo(word);
    }

    @Override
    public int shortestDistance(final String word1, final String word2) {
        if (word1.length() != word2.length()) {
            return -1;
        }
        return getDistanceMatrix(word1).shortestDistance(word1, word2);
    }

    @Override
    public Map<String, Integer> getWordDistances(String word) {
        return getDistanceMatrix(word).getWordDistances(word);
    }

    /**
     * Finds the longest shortest path between two words of the given
     * length. For example, the smallest number of steps to transform
     * 'ash' into 'ivy' is 13. There are no other pairs of three letter
     * words that have a greater number of transformation steps so this
     * pair is returned.
     * @param wordLength the length of the words to find paths between
     * @return the word pair, along with the distance of their path
     * @throws MatrixNotFoundException if no distance matrix was created
     * for words of this length
     */
    public WordPairDistance findLongestShortestPath(int wordLength) {
        return getDistanceMatrix(wordLength).findLongestShortestPath();
    }

    private DistanceMatrix getDistanceMatrix(String word) {
        final DistanceMatrix matrix = matrices.getDistanceMatrix(word);
        if (matrix == null) {
            throw new WordNotFoundException(word);
        }
        return matrix;
    }

    private DistanceMatrix getDistanceMatrix(int wordLength) {
        final DistanceMatrix matrix = matrices.getDistanceMatrix(wordLength);
        if (matrix == null) {
            throw new MatrixNotFoundException(wordLength);
        }
        return matrix;
    }
}
