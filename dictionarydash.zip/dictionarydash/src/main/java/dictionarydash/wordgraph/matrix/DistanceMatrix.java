package dictionarydash.wordgraph.matrix;

import dictionarydash.wordgraph.NoPathFoundException;
import dictionarydash.wordgraph.WordAdjacency;
import dictionarydash.wordgraph.WordNotFoundException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DistanceMatrix {

    private final List<String> words;
    private final short[][] distanceMatrix;

    public DistanceMatrix(final List<String> words) {
        this.words = words;
        distanceMatrix = floydWarshall(words.size());
    }

    /**
     * Return a 2D size*size matrix of shorts of the value -1
     *
     * @param size the size of the matrix
     * @return the initialised matrix
     */
    private short[][] floydWarshall(int size) {
        final short[][] matrix = new short[size][size];
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                if (i == j) {
                    matrix[i][j] = 0;
                } else {
                    String word1 = words.get(i);
                    String word2 = words.get(j);
                    if (WordAdjacency.isAdjacent(word1, word2)) {
                        matrix[i][j] = 1;
                    } else {
                        matrix[i][j] = (short) (Short.MAX_VALUE / 2);
                    }
                }
            }
        }
        //Uses the Floyd-Warshall algorithm to get the shortest distance from every word
        //to every other word
        for (int k = 0; k < size; k++) {
            for (int i = 0; i < size; i++) {
                for (int j = 0; j < i; j++) {
                    short distanceSum = (short) (matrix[i][k] + matrix[k][j]);
                    if (distanceSum < matrix[i][j]) {
                        matrix[j][i] = distanceSum;
                        matrix[i][j] = distanceSum;
                    }
                }
            }
        }
        //Reset max value to -1 to indicate no path
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                if (matrix[i][j] == (short) (Short.MAX_VALUE / 2)) {
                    matrix[i][j] = -1;
                }
            }
        }
        return matrix;
    }

    /**
     * Return the list of words adjacent to the given word
     *
     * @param word word to find words adjacent to
     * @return list of adjacent words
     */
    public List<String> wordsAdjacentTo(final String word) {
        final int wordIndex = getWordIndex(word);
        final List<String> adjacentWords = new ArrayList<>();
        for (short i = 0; i < words.size(); i++) {
            if (distanceMatrix[wordIndex][i] == 1) {
                adjacentWords.add(words.get(i));
            }
        }
        return adjacentWords;
    }

    public int shortestDistance(final String word1, final String word2) {
        if (word1.length() != word2.length()) {
            return -1;
        }
        final int word1Index = getWordIndex(word1);
        final int word2Index = getWordIndex(word2);
        return distanceMatrix[word1Index][word2Index];
    }

    private int getWordIndex(final String word) {
        int wordIndex = words.indexOf(word);
        if (wordIndex == -1) {
            throw new WordNotFoundException(word);
        }
        return wordIndex;
    }

    /**
     * Find the two words with the longest shortest path between them.
     *
     * @return the WordPairDistance describing the word pair with the longest path of words between them and their distance
     * @throws NoPathFoundException exception if no paths were found between any word
     */
    public WordPairDistance findLongestShortestPath() {
        String word1 = null;
        String word2 = null;
        short maxDistance = 0;

        for (int i = 0; i < distanceMatrix.length; i++) {
            for (int j = 0; j < distanceMatrix[0].length; j++) {
                short distance = distanceMatrix[i][j];
                if (distance > maxDistance) {
                    maxDistance = distance;
                    word1 = words.get(i);
                    word2 = words.get(j);
                }
            }
        }

        if (word1 == null) {
            throw new NoPathFoundException();
        }

        return new WordPairDistance(word1, word2, maxDistance);
    }

    public Map<String, Integer> getWordDistances(String word) {
        final Map<String, Integer> distances = new HashMap<>();

        int wordIndex = getWordIndex(word);
        for (short i = 0; i < words.size(); i++) {
            distances.put(words.get(i), (int) distanceMatrix[wordIndex][i]);
        }
        return distances;
    }
}