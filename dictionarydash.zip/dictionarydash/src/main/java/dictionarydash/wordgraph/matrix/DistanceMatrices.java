package dictionarydash.wordgraph.matrix;

import dictionarydash.dictionary.Dictionary;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class DistanceMatrices {

    private final Map<Integer, DistanceMatrix> distanceMatricesByWordLength;

    public DistanceMatrices(final Dictionary dictionary) {
        distanceMatricesByWordLength = initialiseDistanceMatrices(dictionary);
    }

    private Map<Integer, DistanceMatrix> initialiseDistanceMatrices(final Dictionary dictionary) {
        final Map<Integer, List<String>> wordsByLength = getWordsByLength(dictionary);
        return wordsByLength.entrySet().parallelStream().collect(
                Collectors.toConcurrentMap(
                        Map.Entry::getKey,
                        e -> new DistanceMatrix(e.getValue())));
    }

    private Map<Integer, List<String>> getWordsByLength(Dictionary dictionary) {
        return dictionary.words().stream().collect(Collectors.groupingBy(String::length));
    }

    public DistanceMatrix getDistanceMatrix(final String word) {
        return getDistanceMatrix(word.length());
    }

    public DistanceMatrix getDistanceMatrix(final int wordLength) {
        return distanceMatricesByWordLength.get(wordLength);
    }
}