package dictionarydash.wordgraph.matrix;

public class MatrixNotFoundException extends RuntimeException {
    public MatrixNotFoundException(final int wordLength) {
        super("Matrix for words of length " + wordLength + " not found");
    }
}