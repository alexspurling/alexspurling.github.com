package dictionarydash.wordgraph;

public class WordNotFoundException extends RuntimeException {
    public WordNotFoundException(final String word) {
        super("Word " + word + " not found in search graph");
    }
}