package dictionarydash.wordgraph;

public class NoPathFoundException extends RuntimeException {
    public NoPathFoundException() {
        super("Path not found");
    }
}
