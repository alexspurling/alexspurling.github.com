package dictionarydash.wordgraph;

import dictionarydash.dictionary.Dictionary;
import dictionarydash.dictionary.ResourceDictionary;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;

public abstract class AbstractWordGraphTest {

    private static final String[] wordListWithMultiplePaths = {"cat", "cam", "dam", "dim", "dig", "hat", "hit", "fit", "fig"};

    protected abstract WordGraph getWordGraph(Dictionary dictionary);

    @Test
    public void testWordsAdjacentToReturnsCorrectListOfAdjacentWords() {
        final Dictionary dictionary = new ResourceDictionary("dictionary1-4letters.txt");
        final WordGraph wordGraph = getWordGraph(dictionary);

        final List<String> adjacentToDog =
                Arrays.asList("bog", "cog", "dig", "doc", "doe", "don", "dos", "dot", "dug", "fog", "hog", "jog", "log", "tog");
        assertEquals(adjacentToDog, wordGraph.wordsAdjacentTo("dog"));
    }

    @Test
    public void findDistanceBetweenWords() {
        final Dictionary dictionary = new TestDictionary("hit", "dot", "dog", "cog", "hot", "log");
        final WordGraph wordGraph = getWordGraph(dictionary);
        assertEquals(0, wordGraph.shortestDistance("dog", "dog"));
        assertEquals(2, wordGraph.shortestDistance("dot", "cog"));
        assertEquals(4, wordGraph.shortestDistance("hit", "cog"));
        assertEquals(4, wordGraph.shortestDistance("log", "hit"));
    }

    @Test
    public void findShortestPathBetweenWordsWhenMultipleExist() {
        final Dictionary dictionary = new TestDictionary(wordListWithMultiplePaths);
        final WordGraph wordGraph = getWordGraph(dictionary);
        assertEquals(4, wordGraph.shortestDistance("cat", "fig"));
    }

    @Test
    public void findNoPathBetweenWordsWhenNoneExists() {
        //No path between cat and fig this time
        final Dictionary dictionary = new TestDictionary("cat", "cam", "dam", "dim", "bet", "hat", "hit", "wit", "fig");
        final WordGraph wordGraph = getWordGraph(dictionary);
        assertEquals(-1, wordGraph.shortestDistance("cat", "fig"));
    }

    @Test
    public void findNoPathBetweenWordsWhenDifferentLengths() {
        final Dictionary dictionary = new TestDictionary(wordListWithMultiplePaths);
        final WordGraph wordGraph = getWordGraph(dictionary);
        assertEquals(-1, wordGraph.shortestDistance("frog", "fig"));
    }

    @Test(expected = WordNotFoundException.class)
    public void testWordsAdjacentToWhenWordNotInDictionary() {
        final Dictionary dictionary = new TestDictionary(wordListWithMultiplePaths);
        final WordGraph wordGraph = getWordGraph(dictionary);

        wordGraph.wordsAdjacentTo("foo");
    }

    @Test(expected = WordNotFoundException.class)
    public void testShortestDistanceWhenFirstWordNotInDictionary() {
        final Dictionary dictionary = new TestDictionary(wordListWithMultiplePaths);
        final WordGraph wordGraph = getWordGraph(dictionary);

        wordGraph.shortestDistance("aaa", "fig");
    }

    @Test(expected = WordNotFoundException.class)
    public void testShortestDistanceWhenSecondWordNotInDictionary() {
        final Dictionary dictionary = new TestDictionary(wordListWithMultiplePaths);
        final WordGraph wordGraph = getWordGraph(dictionary);

        wordGraph.shortestDistance("cat", "bbb");
    }

    @Test
    public void testGetWordDistances() {
        final WordGraph wordGraph = getWordGraph(new ResourceDictionary("dictionary1-4letters.txt"));

        final Map<String, Integer> wordDistances = wordGraph.getWordDistances("imp");

        assertEquals(1, (long)wordDistances.get("amp"));
        assertEquals(2, (long)wordDistances.get("asp"));
        assertEquals(3, (long)wordDistances.get("ask"));
        assertEquals(4, (long)wordDistances.get("ark"));
        assertEquals(5, (long)wordDistances.get("irk"));
        assertEquals(6, (long)wordDistances.get("ink"));
        assertEquals(7, (long)wordDistances.get("inn"));
        assertEquals(8, (long)wordDistances.get("ion"));
        assertEquals(9, (long)wordDistances.get("won"));
        assertEquals(10, (long)wordDistances.get("woo"));
        assertEquals(11, (long)wordDistances.get("who"));
        assertEquals(12, (long)wordDistances.get("oho"));
        assertEquals(13, (long)wordDistances.get("ohm"));
    }

    protected static class TestDictionary implements Dictionary {

        private final List<String> words;

        public TestDictionary(final String... words) {
            this.words = Arrays.asList(words);
        }

        @Override
        public List<String> words() {
            return words;
        }
    }
}
