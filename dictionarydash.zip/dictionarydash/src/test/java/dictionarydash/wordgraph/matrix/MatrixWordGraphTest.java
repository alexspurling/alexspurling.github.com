package dictionarydash.wordgraph.matrix;

import dictionarydash.dictionary.Dictionary;
import dictionarydash.dictionary.ResourceDictionary;
import dictionarydash.wordgraph.AbstractWordGraphTest;
import dictionarydash.wordgraph.WordGraph;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class MatrixWordGraphTest extends AbstractWordGraphTest {

    @Override
    protected WordGraph getWordGraph(Dictionary dictionary) {
        return new MatrixWordGraph(dictionary);
    }

    @Test
    public void testFindLongestShortestPathForEachWordLength() {
        final Dictionary dictionary = new ResourceDictionary("dictionary1-4letters.txt");
        final MatrixWordGraph wordGraph = new MatrixWordGraph(dictionary);

        assertEquals(new WordPairDistance("a", "b", 1), wordGraph.findLongestShortestPath(1));
        assertEquals(new WordPairDistance("fa", "or", 6), wordGraph.findLongestShortestPath(2));
        assertEquals(new WordPairDistance("imp", "ohm", 13), wordGraph.findLongestShortestPath(3));
        assertEquals(new WordPairDistance("chum", "imps", 17), wordGraph.findLongestShortestPath(4));
    }
}
