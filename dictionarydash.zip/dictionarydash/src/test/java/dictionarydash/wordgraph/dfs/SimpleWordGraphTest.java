package dictionarydash.wordgraph.dfs;

import dictionarydash.dictionary.Dictionary;
import dictionarydash.wordgraph.AbstractWordGraphTest;
import dictionarydash.wordgraph.WordGraph;

public class SimpleWordGraphTest extends AbstractWordGraphTest {

    @Override
    protected WordGraph getWordGraph(Dictionary dictionary) {
        return new SimpleWordGraph(dictionary);
    }
}
