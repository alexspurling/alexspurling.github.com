package dictionarydash.wordgraph;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class WordAdjacencyTest {

    @Test
    public void testIsAdjacentTo() {
        assertEquals(true, WordAdjacency.isAdjacent("aaa", "aab"));
        assertEquals(false, WordAdjacency.isAdjacent("aaa", "aaa"));
        assertEquals(false, WordAdjacency.isAdjacent("aaaa", "aab"));
        assertEquals(false, WordAdjacency.isAdjacent("aaa", "aaab"));
        assertEquals(true, WordAdjacency.isAdjacent("cat", "hat"));
        assertEquals(true, WordAdjacency.isAdjacent("dog", "log"));
    }
}
