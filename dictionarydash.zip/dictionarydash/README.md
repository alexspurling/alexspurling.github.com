# Dictionary Dash

### Test and Build the Application

To test and build the application, run the following command:

`./gradlew clean test`

### Description

Dictionary Dash implements an algorithm to find the shortest number of steps needed to transform one
word to another. The transformation rules are:

* Only one letter can be changed at a time
* Each intermediate word must exist in the dictionary
* At each step, exactly one character is replaced with another character

### How did you approach this problem?

I implemented two different algorithms, first a breadth first search and then a distance-matrix 
algorithm to solve this problem. Breadth first search has the advantage that it is simple and 
relatively fast when doing a small number of searches. The distance-matrix algorithm (based on 
[Floyd-Warshall](https://en.wikipedia.org/wiki/Floyd%E2%80%93Warshall_algorithm)) has a high
set-up cost but very fast lookups for word distances.

### How did you check the solution is correct?

I wrote tests in conjunction with the algorithms. I did not follow a strict TDD process but
I used the tests to help drive the design and simultaneously test that both algorithm solutions
behaved consistently. I tried to thinking of all the edge-cases that might be encountered. If I
had more time, I might investigate the possibility of property-based tests. Also, I considered
using the Groovy test framework [Spock](https://spockframework.github.io/spock/docs/) but felt 
it was unnecessary for such a simple application.

### Assumptions

* A word is *adjacent* to another word if it can be transformed into it by replacing a single letter.
* Your inputs are not null. This follows the Clean Code convention against null-checks and 
defensive programming
* You only want to find a small number of word distances. When using the 
breadth-first-search algorithm, repeated searches (i.e. millions) would take a long time. When 
initialising the distance-matrix algorithm, the set-up cost can-be huge when loading a large
dictionary. Depending on the requirements, a choice would have to be made about which algorithm
to use.